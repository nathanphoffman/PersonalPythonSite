#!/usr/bin/env bash
cd "$(dirname "$0")"
./SpaceCombatServer --port 7777
