SPACE COMBAT - double-click SpaceCombat.exe (runs fullscreen, Esc to quit)

Mouse: steer          W/S: throttle        A/D R/F: strafe     Q/E: roll
Left click / Space: fire cannon            Right click: fire missile
1-7: pick cannon      F1-F7: pick missile type
Enter: restart after dying
