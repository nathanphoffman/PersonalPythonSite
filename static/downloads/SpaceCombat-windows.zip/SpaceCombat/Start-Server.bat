@echo off
SpaceCombatServer.exe --port 7777
pause
